from flask import Flask, request, jsonify
import subprocess
import os

app = Flask(__name__)

@app.route("/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "Nenhum arquivo enviado"}), 400

    file = request.files["file"]
    save_path = os.path.join("/home/ubuntu/uploads", file.filename)
    file.save(save_path)
    return jsonify({"status": "ok", "path": save_path})

@app.route("/process", methods=["POST"])
def process_file():
    data = request.json
    input_path = data.get("input_path") or data.get("s3_path")
    output_path = data.get("output_path") or data.get("output_s3_path") or "/home/ubuntu/output/result.csv"

    if not input_path:
        return jsonify({"error": "Caminho de entrada não fornecido"}), 400

    try:
        result = subprocess.run(
            ["python3", "/home/ubuntu/app/process_job.py", input_path, output_path],
            capture_output=True, text=True, check=True
        )
        return jsonify({"status": "ok", "stdout": result.stdout})
    except subprocess.CalledProcessError as e:
        return jsonify({"status": "error", "stderr": e.stderr}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
