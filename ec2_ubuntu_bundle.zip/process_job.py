import sys
import os
import boto3
import pandas as pd
from pyspark.sql import SparkSession

def main(input_path, output_path):
    spark = SparkSession.builder.appName("EC2PySparkProcessor").getOrCreate()

    # Detecta se caminho é S3 ou local
    if input_path.startswith("s3://"):
        s3 = boto3.client("s3")
        bucket, key = input_path.replace("s3://", "").split("/", 1)
        local_input = f"/home/ubuntu/uploads/{os.path.basename(key)}"
        s3.download_file(bucket, key, local_input)
    else:
        local_input = input_path

    # Carrega CSV com Spark
    df = spark.read.option("header", True).csv(local_input)
    df.createOrReplaceTempView("data")

    # Exemplo de transformação: contar registros
    result = spark.sql("SELECT COUNT(*) as total_rows FROM data")
    result.show()

    # Converte para Pandas e salva resultado
    pdf = result.toPandas()
    local_output = output_path if not output_path.startswith("s3://") else "/home/ubuntu/output/result.csv"
    pdf.to_csv(local_output, index=False)

    # Upload para S3 se necessário
    if output_path.startswith("s3://"):
        bucket, key = output_path.replace("s3://", "").split("/", 1)
        s3.upload_file(local_output, bucket, key)

    spark.stop()

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Uso: python3 process_job.py <input_path> <output_path>")
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
